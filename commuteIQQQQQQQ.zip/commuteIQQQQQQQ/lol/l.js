'use strict';

document.addEventListener("DOMContentLoaded", async () => {
  const appSource = document.getElementById("app-source");
  const appDestination = document.getElementById("app-destination");
  const appFare = document.getElementById("app-fare");
  const appTime = document.getElementById("app-time");

  const rapidoCost = document.getElementById("rapido-cost");
  const olaCost = document.getElementById("ola-cost");
  const uberCost = document.getElementById("uber-cost");

  const rapidoTime = document.getElementById("rapido-time");
  const olaTime = document.getElementById("ola-time");
  const uberTime = document.getElementById("uber-time");

  const fareRates = { rapido: 12, ola: 15, uber: 18 }; // ₹ per km
  const avgSpeeds = { rapido: 30, ola: 25, uber: 28 }; // km/h

  let map = L.map("map").setView([17.3850, 78.4867], 12);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "&copy; OpenStreetMap contributors"
  }).addTo(map);

  let sourceMarker, destinationMarker, routeLine;

  // Retrieve stored ride details
  const source = localStorage.getItem("source") || "Not Provided";
  const destination = localStorage.getItem("destination") || "Not Provided";

  appSource.textContent = source;
  appDestination.textContent = destination;

  if (source === "Not Provided" || destination === "Not Provided") {
    alert("No ride details found. Please enter ride details on the main page.");
    return;
  }

  // Fetch lat/lon from stored locations
  const lat1 = parseFloat(localStorage.getItem("sourceLat"));
  const lon1 = parseFloat(localStorage.getItem("sourceLon"));
  const lat2 = parseFloat(localStorage.getItem("destinationLat"));
  const lon2 = parseFloat(localStorage.getItem("destinationLon"));

  if (!lat1 || !lon1 || !lat2 || !lon2) {
    alert("Location coordinates are missing. Please re-enter your ride details.");
    return;
  }

  // Add markers to the map
  sourceMarker = L.marker([lat1, lon1]).addTo(map).bindPopup("Source Location").openPopup();
  destinationMarker = L.marker([lat2, lon2]).addTo(map).bindPopup("Destination Location").openPopup();

  // Draw route
  routeLine = L.polyline([[lat1, lon1], [lat2, lon2]], { color: "blue", weight: 4 }).addTo(map);
  map.fitBounds([[lat1, lon1], [lat2, lon2]]);

  // Calculate distance using Leaflet
  const distance = map.distance(L.latLng(lat1, lon1), L.latLng(lat2, lon2)) / 1000; // Convert meters to km

  // Calculate estimated fare and time
  const estimatedFare = {
    rapido: (distance * fareRates.rapido).toFixed(2),
    ola: (distance * fareRates.ola).toFixed(2),
    uber: (distance * fareRates.uber).toFixed(2)
  };

  const estimatedTime = {
    rapido: `${Math.ceil((distance / avgSpeeds.rapido) * 60)} min`,
    ola: `${Math.ceil((distance / avgSpeeds.ola) * 60)} min`,
    uber: `${Math.ceil((distance / avgSpeeds.uber) * 60)} min`
  };

  // Store estimated values in localStorage
  localStorage.setItem("rapido-cost", estimatedFare.rapido);
  localStorage.setItem("ola-cost", estimatedFare.ola);
  localStorage.setItem("uber-cost", estimatedFare.uber);

  localStorage.setItem("rapido-time", estimatedTime.rapido);
  localStorage.setItem("ola-time", estimatedTime.ola);
  localStorage.setItem("uber-time", estimatedTime.uber);

  // Display the calculated values
  appFare.textContent = `₹${estimatedFare.ola}`;
  appTime.textContent = estimatedTime.ola;

  rapidoCost.textContent = `₹${estimatedFare.rapido}`;
  olaCost.textContent = `₹${estimatedFare.ola}`;
  uberCost.textContent = `₹${estimatedFare.uber}`;

  rapidoTime.textContent = estimatedTime.rapido;
  olaTime.textContent = estimatedTime.ola;
  uberTime.textContent = estimatedTime.uber;

  // Clear ride details button
  document.getElementById("clearData").addEventListener("click", () => {
    localStorage.removeItem("source");
    localStorage.removeItem("destination");
    localStorage.removeItem("fare");
    localStorage.removeItem("time");
    localStorage.removeItem("sourceLat");
    localStorage.removeItem("sourceLon");
    localStorage.removeItem("destinationLat");
    localStorage.removeItem("destinationLon");
    localStorage.removeItem("rapido-cost");
    localStorage.removeItem("ola-cost");
    localStorage.removeItem("uber-cost");
    localStorage.removeItem("rapido-time");
    localStorage.removeItem("ola-time");
    localStorage.removeItem("uber-time");

    alert("Ride details cleared.");
    window.location.href = "index.html";
  });
});
