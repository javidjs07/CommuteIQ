'use strict';

// ✅ Handle CONNECT button click to navigate to app.html
const connectButton = document.querySelector(".connect-button");
if (connectButton) {
  connectButton.addEventListener("click", (event) => {
    event.preventDefault();
    window.location.href = "app.html";
  });
}

// ✅ Store ride details when route is calculated
document.getElementById("calculateRoute")?.addEventListener("click", () => {
  const source = document.getElementById("source").value.trim();
  const destination = document.getElementById("destination").value.trim();
  const fare = document.getElementById("fare-info").textContent.trim();
  const time = document.getElementById("time-info").textContent.trim();

  if (source && destination) {
    localStorage.setItem("source", source);
    localStorage.setItem("destination", destination);
    localStorage.setItem("fare", fare);
    localStorage.setItem("time", time);
    alert("Ride details saved successfully!");
  } else {
    alert("Please enter both source and destination.");
  }
});

// ✅ Login Functionality - Redirect to About Page
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", function (event) {
    event.preventDefault();
    const userName = document.getElementById("userName").value.trim();
    const userPhone = document.getElementById("userPhone").value.trim();
    const userPassword = document.getElementById("userPassword").value.trim();

    if (!/^[6-9]{1}[0-9]{9}$/.test(userPhone)) {
      alert("Please enter a valid 10-digit Indian phone number.");
      return;
    }

    if (userPassword !== "root") {
      alert("Incorrect password. Please enter the correct password.");
      return;
    }

    localStorage.setItem("userName", userName);
    localStorage.setItem("userPhone", userPhone);
    window.location.href = "index.html#about";
  });
}

// ✅ Ensure User is Logged In Before Accessing Dashboard
document.addEventListener("DOMContentLoaded", () => {
  const userName = localStorage.getItem("userName");
  const userPhone = localStorage.getItem("userPhone");

  if (!userName || !userPhone) {
    window.location.href = "login.html";
  } else {
    document.getElementById("user-name").textContent = userName;
    document.getElementById("user-phone").textContent = userPhone;
  }

  const pages = document.querySelectorAll(".page");
  const navLinks = document.querySelectorAll(".nav-link");

  navLinks.forEach(link => {
    link.addEventListener("click", () => {
      pages.forEach(page => page.classList.remove("active"));
      navLinks.forEach(nav => nav.classList.remove("active"));

      const targetPage = document.querySelector(`.page[data-page='${link.dataset.page}']`);
      if (targetPage) {
        targetPage.classList.add("active");
        link.classList.add("active");
      }
    });
  });

  const hash = window.location.hash.substring(1);
  if (hash) {
    pages.forEach(page => page.classList.remove("active"));
    navLinks.forEach(nav => nav.classList.remove("active"));

    const activePage = document.querySelector(`.page[data-page='${hash}']`);
    if (activePage) {
      activePage.classList.add("active");
      document.querySelector(`.nav-link[data-page='${hash}']`)?.classList.add("active");
    }
  }

  const map = L.map('map').setView([17.3850, 78.4867], 13);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(map);

  let sourceMarker, destinationMarker;

  async function fetchLocationSuggestions(inputElement, suggestionListId, markerType) {
    const suggestionList = document.getElementById(suggestionListId);
    inputElement.addEventListener("input", async () => {
      const query = inputElement.value.trim();
      if (query.length < 2) return;

      const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${query}, Hyderabad, India`);
      const data = await response.json();

      suggestionList.innerHTML = "";
      data.slice(0, 5).forEach(location => {
        let listItem = document.createElement("li");
        listItem.textContent = location.display_name;
        listItem.addEventListener("click", () => {
          inputElement.value = location.display_name;
          suggestionList.innerHTML = "";

          const lat = parseFloat(location.lat);
          const lon = parseFloat(location.lon);

          if (markerType === "source") {
            if (sourceMarker) map.removeLayer(sourceMarker);
            sourceMarker = L.marker([lat, lon]).addTo(map).bindPopup("Source Location").openPopup();
            localStorage.setItem("sourceLat", lat);
            localStorage.setItem("sourceLon", lon);
          } else {
            if (destinationMarker) map.removeLayer(destinationMarker);
            destinationMarker = L.marker([lat, lon]).addTo(map).bindPopup("Destination Location").openPopup();
            localStorage.setItem("destinationLat", lat);
            localStorage.setItem("destinationLon", lon);
          }

          map.setView([lat, lon], 13);

          if (localStorage.getItem("sourceLat") && localStorage.getItem("destinationLat")) {
            handleRouteSelection();
          }
        });
        suggestionList.appendChild(listItem);
      });
    });
  }

  function checkHyderabadBoundary(source, destination) {
    const hyderabadBounds = {
      north: 17.6000,
      south: 17.2000,
      east: 78.6500,
      west: 78.3000
    };

    const isSourceInHyd = source.lat >= hyderabadBounds.south && source.lat <= hyderabadBounds.north &&
                          source.lon >= hyderabadBounds.west && source.lon <= hyderabadBounds.east;

    const isDestInHyd = destination.lat >= hyderabadBounds.south && destination.lat <= hyderabadBounds.north &&
                        destination.lon >= hyderabadBounds.west && destination.lon <= hyderabadBounds.east;

    return isSourceInHyd && isDestInHyd;
  }

  function handleRouteSelection() {
    const srcLat = parseFloat(localStorage.getItem("sourceLat"));
    const srcLon = parseFloat(localStorage.getItem("sourceLon"));
    const destLat = parseFloat(localStorage.getItem("destinationLat"));
    const destLon = parseFloat(localStorage.getItem("destinationLon"));

    if (!srcLat || !srcLon || !destLat || !destLon) return;

    const isValid = checkHyderabadBoundary(
      { lat: srcLat, lon: srcLon },
      { lat: destLat, lon: destLon }
    );

    const routeStatus = document.getElementById("routeStatus");
    const fareInfo = document.getElementById("fare-info");
    const timeInfo = document.getElementById("time-info");

    if (isValid) {
      routeStatus.textContent = "Route Selected!";
      fareInfo.textContent = "₹120";
      timeInfo.textContent = "25 mins";
    } else {
      routeStatus.textContent = "No Route Found!";
      fareInfo.textContent = "N/A";
      timeInfo.textContent = "N/A";
    }
  }

  fetchLocationSuggestions(document.getElementById("source"), "source-suggestions", "source");
  fetchLocationSuggestions(document.getElementById("destination"), "destination-suggestions", "destination");

  document.getElementById("confirmRide")?.addEventListener("click", () => {
    alert("Your ride has been confirmed!");
  });

  const logoutButton = document.getElementById("logoutButton");
  if (logoutButton) {
    logoutButton.addEventListener("click", () => {
      localStorage.clear();
      window.location.href = "login.html";
    });
  }
});
