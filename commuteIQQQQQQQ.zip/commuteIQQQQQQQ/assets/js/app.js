'use strict';

document.addEventListener("DOMContentLoaded", async () => {
  const appSource = document.getElementById("app-source");
  const appDestination = document.getElementById("app-destination");
  const appFare = document.getElementById("app-fare");
  const appTime = document.getElementById("app-time");
  const routeStatus = document.getElementById("route-status");

  const rideFields = ["rapido", "ola", "uber"];
  const rideTypes = ["bike", "auto", "cab"];

  const fareRates = {
    rapido: { bike: 17, auto: 22, cab: 26 },
    ola: { bike: 18, auto: 24, cab: 28 },
    uber: { bike: 16, auto: 23, cab: 25 }
  };

  const avgSpeeds = {
    rapido: { bike: 35, auto: 30, cab: 25 },
    ola: { bike: 32, auto: 28, cab: 24 },
    uber: { bike: 34, auto: 29, cab: 26 }
  };

  let map = L.map("map").setView([17.3850, 78.4867], 12);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "&copy; OpenStreetMap contributors"
  }).addTo(map);

  const source = localStorage.getItem("source") || "Not Provided";
  const destination = localStorage.getItem("destination") || "Not Provided";

  appSource.textContent = source;
  appDestination.textContent = destination;

  if (source === "Not Provided" || destination === "Not Provided") {
    routeStatus.innerHTML = `<strong>Selected Route:</strong> No Route Found`;
    alert("No ride details found. Please enter ride details on the main page.");
    return;
  }

  const lat1 = parseFloat(localStorage.getItem("sourceLat"));
  const lon1 = parseFloat(localStorage.getItem("sourceLon"));
  const lat2 = parseFloat(localStorage.getItem("destinationLat"));
  const lon2 = parseFloat(localStorage.getItem("destinationLon"));

  if (isNaN(lat1) || isNaN(lon1) || isNaN(lat2) || isNaN(lon2)) {
    routeStatus.innerHTML = `<strong>Selected Route:</strong> No Route Found`;
    alert("Location coordinates are missing or invalid. Please re-enter your ride details.");
    return;
  }

  routeStatus.innerHTML = `<strong>Selected Route:</strong> Valid Route Selected`;

  L.marker([lat1, lon1]).addTo(map).bindPopup("Source Location").openPopup();
  L.marker([lat2, lon2]).addTo(map).bindPopup("Destination Location").openPopup();

  L.polyline([[lat1, lon1], [lat2, lon2]], { color: "blue", weight: 4 }).addTo(map);
  map.fitBounds([[lat1, lon1], [lat2, lon2]]);

  const distance = map.distance(L.latLng(lat1, lon1), L.latLng(lat2, lon2)) / 1000;

  let defaultFare = 0, defaultTime = "--";

  rideFields.forEach(company => {
    rideTypes.forEach(type => {
      const fare = (distance * fareRates[company][type]).toFixed(2);
      const time = `${Math.ceil((distance / avgSpeeds[company][type]) * 60)} min`;

      const fareSpan = document.getElementById(`${company}-${type}-fare`);
      const timeSpan = document.getElementById(`${company}-${type}-time`);

      if (fareSpan) fareSpan.textContent = fare;
      if (timeSpan) timeSpan.textContent = time;

      localStorage.setItem(`${company}-${type}-fare`, fare);
      localStorage.setItem(`${company}-${type}-time`, time);

      if (company === "ola" && type === "bike") {
        defaultFare = fare;
        defaultTime = time;
      }
    });
  });

  appFare.textContent = `₹${defaultFare}`;
  appTime.textContent = defaultTime;

  document.getElementById("clearData").addEventListener("click", () => {
    [
      "source", "destination", "fare", "time",
      "sourceLat", "sourceLon", "destinationLat", "destinationLon"
    ].forEach(k => localStorage.removeItem(k));

    rideFields.forEach(c =>
      rideTypes.forEach(t => {
        localStorage.removeItem(`${c}-${t}-fare`);
        localStorage.removeItem(`${c}-${t}-time`);
      })
    );

    alert("Ride details cleared.");
    window.location.href = "index.html";
  });
});
